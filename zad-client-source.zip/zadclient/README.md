# Zad Client (DountSMP)

كلاينت Fabric لماين كرافت 1.21.11 بثيم وردي. فيه قائمة ClickGUI بلوحات تنسحب، وHUD، ومودات خفيفة.

## المميزات

| اللوحة | المودات |
|---|---|
| HUD | FPS، Ping، الإحداثيات |
| Movement | Toggle Sprint |
| Visuals | Zoom سلس (اضغط C) |

- **Right Shift**: يفتح قائمة Zad Client. اضغط على اسم المود لتشغيله أو إطفائه، واسحب عنوان اللوحة لتحريكها.
- الإعدادات تنحفظ تلقائياً في `config/zadclient.json`.

## البناء

المتطلبات: JDK 21 وإنترنت (عشان Gradle ينزل Minecraft وFabric).

```
./gradlew build
```

الملف الناتج: `build/libs/zad-client-1.0.0.jar`. حطه في مجلد `mods` مع Fabric Loader وFabric API لنسخة 1.21.11.

### إذا فشل البناء

أرقام الإصدارات في `gradle.properties` (Yarn وLoader وFabric API وLoom) لازم تطابق الصفحة الرسمية https://fabricmc.net/develop لنسخة 1.21.11. أسهل حل:

1. حمّل قالب مشروع جاهز من https://fabricmc.net/develop/template لنسخة 1.21.11.
2. انسخ مجلد `src/main/java/com/zadclient` وملفات `src/main/resources` فوق القالب.
3. عدّل اسم المود في `fabric.mod.json` إذا لزم.

## هيكل الكود

```
com.zadclient
├── ZadClient            نقطة الدخول: المفاتيح، التيك، رسم الـ HUD
├── config/Config        حفظ وقراءة حالة المودات (JSON)
├── gui/ClickGuiScreen   القائمة: اللوحات والأنيميشن والسحب
├── gui/Theme            ألوان الثيم الوردي
├── mixin/GameRendererMixin   تعديل الـ FOV للزوم
└── module/              Module, Category, ModuleManager + impl/ (كل مود بملف)
```

## إضافة مود جديد

1. أنشئ كلاس يرث `Module` في `module/impl`.
2. اكتب منطقه في `onTick` أو `hudLine`.
3. سجله في `ModuleManager`.

يظهر تلقائياً في القائمة وينحفظ في الإعدادات.
