package com.zadclient.module;

import com.zadclient.module.impl.CoordsModule;
import com.zadclient.module.impl.FpsModule;
import com.zadclient.module.impl.PingModule;
import com.zadclient.module.impl.ToggleSprintModule;
import com.zadclient.module.impl.ZoomModule;

import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
	private final List<Module> modules = new ArrayList<>();

	public ModuleManager() {
		modules.add(new FpsModule());
		modules.add(new PingModule());
		modules.add(new CoordsModule());
		modules.add(new ToggleSprintModule());
		modules.add(new ZoomModule());
	}

	public List<Module> all() {
		return modules;
	}

	public List<Module> in(Category category) {
		List<Module> out = new ArrayList<>();
		for (Module m : modules) {
			if (m.category == category) out.add(m);
		}
		return out;
	}

	public <T extends Module> T get(Class<T> type) {
		for (Module m : modules) {
			if (type.isInstance(m)) return type.cast(m);
		}
		throw new IllegalStateException("Module not registered: " + type.getSimpleName());
	}
}
