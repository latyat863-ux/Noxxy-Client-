package com.zadclient.module.impl;

import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.MinecraftClient;

public class FpsModule extends Module {
	public FpsModule() {
		super("FPS", Category.HUD);
		setEnabled(true);
	}

	@Override
	public String hudLine(MinecraftClient mc) {
		return "FPS: " + mc.getCurrentFps();
	}
}
