package com.zadclient.module.impl;

import com.zadclient.ZadClient;
import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.MinecraftClient;

/** Hold the zoom key (default C) to zoom in smoothly. The FOV change itself lives in GameRendererMixin. */
public class ZoomModule extends Module {
	private static final float ZOOM_FACTOR = 4.0f;

	/** Current zoom blend, 0 = no zoom, 1 = fully zoomed. */
	private float blend;

	public ZoomModule() {
		super("Zoom", Category.VISUALS);
		setEnabled(true);
	}

	@Override
	public void onTick(MinecraftClient mc) {
		boolean zooming = isEnabled() && ZadClient.zoomKey != null && ZadClient.zoomKey.isPressed();
		float target = zooming ? 1.0f : 0.0f;
		blend += (target - blend) * 0.35f;
		if (Math.abs(target - blend) < 0.001f) blend = target;
	}

	public float applyTo(float fov) {
		if (blend <= 0.0f) return fov;
		float zoomed = fov / ZOOM_FACTOR;
		return fov + (zoomed - fov) * blend;
	}
}
