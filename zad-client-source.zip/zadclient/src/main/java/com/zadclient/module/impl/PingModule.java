package com.zadclient.module.impl;

import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;

public class PingModule extends Module {
	public PingModule() {
		super("Ping", Category.HUD);
		setEnabled(true);
	}

	@Override
	public String hudLine(MinecraftClient mc) {
		if (mc.player == null || mc.getNetworkHandler() == null) return null;
		PlayerListEntry entry = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
		if (entry == null) return "Ping: --";
		return "Ping: " + entry.getLatency() + " ms";
	}
}
