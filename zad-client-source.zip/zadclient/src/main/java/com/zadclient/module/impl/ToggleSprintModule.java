package com.zadclient.module.impl;

import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.MinecraftClient;

/** Holds sprint for you while you walk forward, the same idea as Toggle Sprint in other clients. */
public class ToggleSprintModule extends Module {
	public ToggleSprintModule() {
		super("Toggle Sprint", Category.MOVEMENT);
	}

	@Override
	public void onTick(MinecraftClient mc) {
		if (mc.player == null || mc.currentScreen != null) return;
		if (mc.options.forwardKey.isPressed() && !mc.player.isSneaking()) {
			mc.options.sprintKey.setPressed(true);
		}
	}
}
