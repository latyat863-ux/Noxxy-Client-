package com.zadclient.module.impl;

import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.MinecraftClient;

public class CoordsModule extends Module {
	public CoordsModule() {
		super("Coords", Category.HUD);
		setEnabled(true);
	}

	@Override
	public String hudLine(MinecraftClient mc) {
		if (mc.player == null) return null;
		return "XYZ: " + mc.player.getBlockX() + " " + mc.player.getBlockY() + " " + mc.player.getBlockZ();
	}
}
