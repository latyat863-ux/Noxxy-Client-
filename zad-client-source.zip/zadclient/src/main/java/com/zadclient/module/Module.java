package com.zadclient.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
	public final String name;
	public final Category category;
	private boolean enabled;

	/** 0..1 animation value used by the ClickGUI for smooth toggling. */
	public float anim;

	protected Module(String name, Category category) {
		this.name = name;
		this.category = category;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public void setEnabled(boolean value) {
		if (this.enabled == value) return;
		this.enabled = value;
		if (value) onEnable(); else onDisable();
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void onEnable() {}

	public void onDisable() {}

	public void onTick(MinecraftClient mc) {}

	/** Text shown on the HUD while enabled, or null if the module draws nothing. */
	public String hudLine(MinecraftClient mc) {
		return null;
	}
}
