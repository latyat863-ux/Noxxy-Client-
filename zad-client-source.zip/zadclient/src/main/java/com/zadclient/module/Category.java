package com.zadclient.module;

public enum Category {
	HUD("HUD"),
	MOVEMENT("Movement"),
	VISUALS("Visuals");

	public final String title;

	Category(String title) {
		this.title = title;
	}
}
