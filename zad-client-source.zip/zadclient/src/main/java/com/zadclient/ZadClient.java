package com.zadclient;

import com.zadclient.config.Config;
import com.zadclient.gui.ClickGuiScreen;
import com.zadclient.gui.Theme;
import com.zadclient.module.Module;
import com.zadclient.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class ZadClient implements ClientModInitializer {
	public static final String NAME = "Zad Client";
	public static final String SERVER = "dountsmp";

	public static ModuleManager modules;
	public static KeyBinding guiKey;
	public static KeyBinding zoomKey;

	@Override
	public void onInitializeClient() {
		modules = new ModuleManager();
		Config.load(modules);

		KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("zadclient", "main"));
		guiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.zadclient.gui", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
		zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.zadclient.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (guiKey.wasPressed()) {
				client.setScreen(new ClickGuiScreen());
			}
			for (Module module : modules.all()) {
				if (module.isEnabled()) module.onTick(client);
			}
		});

		HudElementRegistry.attachElementAfter(
				VanillaHudElements.MISC_OVERLAYS,
				Identifier.of("zadclient", "hud"),
				(context, tickCounter) -> {
					MinecraftClient mc = MinecraftClient.getInstance();
					if (mc.options.hudHidden || mc.getDebugHud().shouldShowDebugHud()) return;

					int y = 6;
					context.drawText(mc.textRenderer, NAME, 6, y, Theme.PINK, true);
					y += 12;
					for (Module module : modules.all()) {
						if (!module.isEnabled()) continue;
						String line = module.hudLine(mc);
						if (line == null) continue;
						context.drawText(mc.textRenderer, line, 6, y, Theme.TEXT, true);
						y += 10;
					}
				});

		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save(modules));
	}
}
