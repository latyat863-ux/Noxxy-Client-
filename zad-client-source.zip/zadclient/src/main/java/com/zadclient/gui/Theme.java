package com.zadclient.gui;

/** All colors are ARGB ints. */
public final class Theme {
	public static final int PANEL_BG      = 0xE0181420;
	public static final int HEADER_BG     = 0xF0241A30;
	public static final int ROW_HOVER     = 0x30FF8FD0;
	public static final int PINK          = 0xFFFF6EC7;
	public static final int PINK_SOFT     = 0xFFFFA8DE;
	public static final int TEXT          = 0xFFEDE6F2;
	public static final int TEXT_DIM      = 0xFF9A90A6;
	public static final int SCREEN_DIM    = 0x90100818;

	private Theme() {}

	public static int lerp(int from, int to, float t) {
		int a = (int) (((from >>> 24) & 255) + (((to >>> 24) & 255) - ((from >>> 24) & 255)) * t);
		int r = (int) (((from >>> 16) & 255) + (((to >>> 16) & 255) - ((from >>> 16) & 255)) * t);
		int g = (int) (((from >>> 8) & 255) + (((to >>> 8) & 255) - ((from >>> 8) & 255)) * t);
		int b = (int) ((from & 255) + ((to & 255) - (from & 255)) * t);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}
}
