package com.zadclient.gui;

import com.zadclient.ZadClient;
import com.zadclient.module.Category;
import com.zadclient.module.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class ClickGuiScreen extends Screen {
	private static final int PANEL_WIDTH = 120;
	private static final int HEADER_HEIGHT = 20;
	private static final int ROW_HEIGHT = 16;
	private static final int GAP = 10;

	private final List<Panel> panels = new ArrayList<>();
	private Panel dragging;
	private double dragOffsetX;
	private double dragOffsetY;

	public ClickGuiScreen() {
		super(Text.literal("Zad Client"));
		int x = 20;
		for (Category category : Category.values()) {
			panels.add(new Panel(category, x, 20));
			x += PANEL_WIDTH + GAP;
		}
	}

	@Override
	public void render(DrawContext context, int mouseX, int mouseY, float delta) {
		context.fill(0, 0, width, height, Theme.SCREEN_DIM);

		for (Panel panel : panels) {
			List<Module> mods = ZadClient.modules.in(panel.category);
			int bodyHeight = mods.size() * ROW_HEIGHT;

			context.fill(panel.x, panel.y, panel.x + PANEL_WIDTH, panel.y + HEADER_HEIGHT, Theme.HEADER_BG);
			context.fill(panel.x, panel.y + HEADER_HEIGHT - 1, panel.x + PANEL_WIDTH, panel.y + HEADER_HEIGHT, Theme.PINK);
			context.drawText(textRenderer, panel.category.title, panel.x + 8, panel.y + 6, Theme.PINK_SOFT, true);

			context.fill(panel.x, panel.y + HEADER_HEIGHT, panel.x + PANEL_WIDTH,
					panel.y + HEADER_HEIGHT + bodyHeight, Theme.PANEL_BG);

			int rowY = panel.y + HEADER_HEIGHT;
			for (Module module : mods) {
				boolean hovered = mouseX >= panel.x && mouseX < panel.x + PANEL_WIDTH
						&& mouseY >= rowY && mouseY < rowY + ROW_HEIGHT;

				float target = module.isEnabled() ? 1.0f : 0.0f;
				module.anim += (target - module.anim) * 0.25f * Math.min(1.0f, delta * 2.0f + 0.5f);

				if (hovered) context.fill(panel.x, rowY, panel.x + PANEL_WIDTH, rowY + ROW_HEIGHT, Theme.ROW_HOVER);
				if (module.anim > 0.01f) {
					int fill = Theme.lerp(0x00FF6EC7, 0xFFFF6EC7, module.anim);
					context.fill(panel.x, rowY, panel.x + PANEL_WIDTH, rowY + ROW_HEIGHT, fill);
				}

				int textColor = Theme.lerp(Theme.TEXT_DIM, 0xFFFFFFFF, module.anim);
				context.drawText(textRenderer, module.name, panel.x + 8, rowY + 4, textColor, false);
				rowY += ROW_HEIGHT;
			}
		}
	}

	@Override
	public boolean mouseClicked(Click click, boolean doubled) {
		double mx = click.x();
		double my = click.y();
		int button = click.button();

		for (int i = panels.size() - 1; i >= 0; i--) {
			Panel panel = panels.get(i);

			if (mx >= panel.x && mx < panel.x + PANEL_WIDTH
					&& my >= panel.y && my < panel.y + HEADER_HEIGHT && button == 0) {
				dragging = panel;
				dragOffsetX = mx - panel.x;
				dragOffsetY = my - panel.y;
				panels.remove(i);
				panels.add(panel);
				return true;
			}

			int rowY = panel.y + HEADER_HEIGHT;
			for (Module module : ZadClient.modules.in(panel.category)) {
				if (mx >= panel.x && mx < panel.x + PANEL_WIDTH && my >= rowY && my < rowY + ROW_HEIGHT) {
					if (button == 0) module.toggle();
					return true;
				}
				rowY += ROW_HEIGHT;
			}
		}
		return super.mouseClicked(click, doubled);
	}

	@Override
	public boolean mouseDragged(Click click, double deltaX, double deltaY) {
		if (dragging != null) {
			dragging.x = (int) (click.x() - dragOffsetX);
			dragging.y = (int) (click.y() - dragOffsetY);
			return true;
		}
		return super.mouseDragged(click, deltaX, deltaY);
	}

	@Override
	public boolean mouseReleased(Click click) {
		dragging = null;
		return super.mouseReleased(click);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void removed() {
		com.zadclient.config.Config.save(ZadClient.modules);
	}

	private static final class Panel {
		final Category category;
		int x;
		int y;

		Panel(Category category, int x, int y) {
			this.category = category;
			this.x = x;
			this.y = y;
		}
	}
}
