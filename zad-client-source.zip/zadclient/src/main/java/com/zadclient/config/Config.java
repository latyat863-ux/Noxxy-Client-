package com.zadclient.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.zadclient.module.Module;
import com.zadclient.module.ModuleManager;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;

/** Saves which modules are on to config/zadclient.json and restores it at startup. */
public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Type TYPE = new TypeToken<Map<String, Boolean>>() {}.getType();

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("zadclient.json");
	}

	public static void load(ModuleManager manager) {
		Path path = file();
		if (!Files.exists(path)) return;
		try {
			Map<String, Boolean> saved = GSON.fromJson(Files.readString(path), TYPE);
			if (saved == null) return;
			for (Module m : manager.all()) {
				Boolean state = saved.get(m.name);
				if (state != null) m.setEnabled(state);
			}
		} catch (IOException | RuntimeException e) {
			System.err.println("[ZadClient] Could not read config: " + e.getMessage());
		}
	}

	public static void save(ModuleManager manager) {
		Map<String, Boolean> out = new LinkedHashMap<>();
		for (Module m : manager.all()) out.put(m.name, m.isEnabled());
		try {
			Files.writeString(file(), GSON.toJson(out));
		} catch (IOException e) {
			System.err.println("[ZadClient] Could not save config: " + e.getMessage());
		}
	}
}
