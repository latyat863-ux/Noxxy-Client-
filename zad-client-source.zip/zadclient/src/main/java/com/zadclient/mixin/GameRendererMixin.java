package com.zadclient.mixin;

import com.zadclient.ZadClient;
import com.zadclient.module.impl.ZoomModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
	@Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
	private void zadclient$zoom(CallbackInfoReturnable<Float> cir) {
		if (ZadClient.modules == null) return;
		ZoomModule zoom = ZadClient.modules.get(ZoomModule.class);
		cir.setReturnValue(zoom.applyTo(cir.getReturnValueF()));
	}
}
